package com.airline;

import java.util.Scanner;

class AirlineReservationSystem {
    private boolean[] seats;
    
    public AirlineReservationSystem() {
        seats = new boolean[100]; // Assuming 100 seats are available
    }
    
    public void reserveSeat() {
        int seatNumber = findAvailableSeat();
        if (seatNumber != -1) {
            seats[seatNumber] = true;
            System.out.println("Seat number " + seatNumber + " has been reserved.");
        } else {
            System.out.println("Sorry, all seats are occupied.");
        }
    }
    
    public void cancelSeat() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter seat number to cancel: ");
        int seatNumber = scanner.nextInt();
        if (seatNumber >= 0 && seatNumber < seats.length) {
            if (seats[seatNumber]) {
                seats[seatNumber] = false;
                System.out.println("Seat number " + seatNumber + " has been cancelled.");
            } else {
                System.out.println("Seat number " + seatNumber + " is not reserved.");
            }
        } else {
            System.out.println("Invalid seat number.");
        }
    }
    
    private int findAvailableSeat() {
        for (int i = 0; i < seats.length; i++) {
            if (!seats[i]) {
                return i;
            }
        }
        return -1; // No available seats
    }
    
    public void displaySeatStatus() {
        System.out.println("Seat Status:");
        for (int i = 0; i < seats.length; i++) {
            System.out.println("Seat " + i + ": " + (seats[i] ? "Occupied" : "Available"));
        }
    }
}
