package com.airline;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AirlineReservationSystem reservationSystem = new AirlineReservationSystem();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("1. Reserve a seat");
            System.out.println("2. Display seat status");
           
            System.out.println("3. Cancel your seat");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    reservationSystem.reserveSeat();
                    break;
                case 2:
                    reservationSystem.displaySeatStatus();
                    break;
                case 3:
                    reservationSystem.cancelSeat();
                    break;  
                    
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
